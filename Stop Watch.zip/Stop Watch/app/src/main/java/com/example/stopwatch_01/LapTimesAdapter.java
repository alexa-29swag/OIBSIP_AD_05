package com.example.stopwatch_01;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LapTimesAdapter extends RecyclerView.Adapter<LapTimesAdapter.LapTimeViewHolder> {
    private List<String> lapTimes;

    public LapTimesAdapter(List<String> lapTimes) {
        this.lapTimes = lapTimes;
    }

    @NonNull
    @Override
    public LapTimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.lap_time_item, parent, false);
        return new LapTimeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LapTimeViewHolder holder, int position) {
        holder.lapTimeText.setText(lapTimes.get(position));
    }

    @Override
    public int getItemCount() {
        return lapTimes.size();
    }

    static class LapTimeViewHolder extends RecyclerView.ViewHolder {
        TextView lapTimeText;

        LapTimeViewHolder(View itemView) {
            super(itemView);
            lapTimeText = itemView.findViewById(R.id.lap_time_text);
        }
    }
}