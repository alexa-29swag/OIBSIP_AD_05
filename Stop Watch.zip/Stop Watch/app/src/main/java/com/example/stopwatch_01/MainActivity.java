package com.example.stopwatch_01;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.cardview.widget.CardView;

import com.google.android.material.button.MaterialButton;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    TextView textView, lapCounter;
    MaterialButton reset, start, pause, lap;
    CardView lapTimesCard;
    RecyclerView lapTimesList;

    int seconds, minutes, milliSeconds;
    long millisecond, startTime, timeBuffer, updateTime = 0L;
    Handler handler;

    // Lap functionality
    private List<String> lapTimes = new ArrayList<>();
    private LapTimesAdapter lapAdapter;
    private int lapCount = 0;
    private long lastLapTime = 0L;
    private boolean isRunning = false;

    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            millisecond = SystemClock.uptimeMillis() - startTime;
            updateTime = timeBuffer + millisecond;
            seconds = (int) (updateTime / 1000);
            minutes = seconds / 60;
            seconds = seconds % 60;
            milliSeconds = (int) (updateTime % 1000);
            textView.setText(MessageFormat.format("{0}:{1}:{2}",
                    String.format(Locale.getDefault(), "%02d", minutes),
                    String.format(Locale.getDefault(), "%02d", seconds),
                    String.format(Locale.getDefault(), "%03d", milliSeconds)));
            handler.postDelayed(this, 10);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize views
        textView = findViewById(R.id.text);
        lapCounter = findViewById(R.id.lap_counter);
        reset = findViewById(R.id.reset);
        start = findViewById(R.id.start);
        pause = findViewById(R.id.pause);
        lap = findViewById(R.id.lap);
        lapTimesCard = findViewById(R.id.lap_times_card);
        lapTimesList = findViewById(R.id.lap_times_list);

        handler = new Handler(Looper.getMainLooper());

        // Initialize RecyclerView
        lapAdapter = new LapTimesAdapter(lapTimes);
        lapTimesList.setLayoutManager(new LinearLayoutManager(this));
        lapTimesList.setAdapter(lapAdapter);

        // Start button click listener
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startTime = SystemClock.uptimeMillis();
                handler.postDelayed(runnable, 0);

                reset.setEnabled(false);
                pause.setEnabled(true);
                start.setEnabled(false);
                lap.setEnabled(true);
                lap.setVisibility(View.VISIBLE);

                isRunning = true;
            }
        });

        // Pause button click listener
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timeBuffer += millisecond;
                handler.removeCallbacks(runnable);

                reset.setEnabled(true);
                pause.setEnabled(false);
                start.setEnabled(true);
                lap.setEnabled(false);

                isRunning = false;
            }
        });

        // Reset button click listener
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Reset timer variables
                millisecond = 0L;
                startTime = 0L;
                updateTime = 0L;
                timeBuffer = 0L;
                seconds = 0;
                minutes = 0;
                milliSeconds = 0;

                // Reset lap variables
                lapCount = 0;
                lastLapTime = 0L;
                lapTimes.clear();
                lapAdapter.notifyDataSetChanged();

                handler.removeCallbacks(runnable);
                textView.setText("00:00:00");
                lapCounter.setText("Laps: 0");
                lapCounter.setVisibility(View.GONE);

                // Reset button states
                start.setEnabled(true);
                pause.setEnabled(false);
                lap.setEnabled(false);
                lap.setVisibility(View.GONE);
                lapTimesCard.setVisibility(View.GONE);

                isRunning = false;
            }
        });

        // Lap button click listener
        lap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isRunning) {
                    lapCount++;
                    long currentTime = updateTime;
                    long lapTime = currentTime - lastLapTime;

                    // Format lap time
                    int lapSeconds = (int) (lapTime / 1000);
                    int lapMinutes = lapSeconds / 60;
                    lapSeconds = lapSeconds % 60;
                    int lapMillis = (int) (lapTime % 1000);

                    String lapTimeString = String.format(Locale.getDefault(),
                            "Lap %d: %02d:%02d:%03d",
                            lapCount, lapMinutes, lapSeconds, lapMillis);

                    lapTimes.add(0, lapTimeString); // Add to beginning of list
                    lapAdapter.notifyItemInserted(0);

                    // Update lap counter
                    lapCounter.setText("Laps: " + lapCount);
                    lapCounter.setVisibility(View.VISIBLE);
                    lapTimesCard.setVisibility(View.VISIBLE);

                    lastLapTime = currentTime;
                }
            }
        });

        // Initialize display
        textView.setText("00:00:00");
    }
}